<?php

class mcLib
{

  public static $request = array();

  public static $mcDB;

  public static $DCAniUabCJTZRZoqVOqPyWvFCsiwIw = array();

  public static $klqHFGteYBcFLfJUzFMxiJDWkivPympnw = array();

  static public function EduXiLMjmLhwBwCyThRBrhfUhATzqBw ( )
  {
    if ( ! empty( $_GET ) )
      self::AIRAWXJxjumZkITCJoWFRRCMoalDgPGGY( $_GET );
    if ( ! empty( $_POST ) )
      self::AIRAWXJxjumZkITCJoWFRRCMoalDgPGGY( $_POST );
    if ( ! empty( $_SESSION ) )
      self::AIRAWXJxjumZkITCJoWFRRCMoalDgPGGY( $_SESSION );
    if ( ! empty( $_COOKIE ) )
      self::AIRAWXJxjumZkITCJoWFRRCMoalDgPGGY( $_COOKIE );
    $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs = @mcLib::ZsYRnxZDEptCpRwWpaTKdgMJIhdrXtSP( $_GET, array() );
    self::$request = @mcLib::ZsYRnxZDEptCpRwWpaTKdgMJIhdrXtSP( $_POST, $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs );
    mcLib::lnasVWpWmmWbLdTpCHBvNRkWutjIMeLIZOU( );
    mcLib::KVfkIrnlxvLbWRYCMcCvTQBYpVZOwNteSE( );
  }

  static public function MVmafwfmjqufexpnGzEfOftlkVUTLXdJcqmVWWE ( $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs )
  {
    if ( is_array( $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs ) )
    {
      foreach ( $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs as $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc => $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM )
      {
        $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc = htmlentities( strip_tags( $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc ) );
        $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs[ $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc ] = str_replace( "\n", "<br>", htmlentities( strip_tags( $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM ) ) );
      }
    }
    else
    {
      $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs = str_replace( "\n", "<br>", htmlentities( strip_tags( $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs ) ) );
    }
    return $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs;
  }

  static public function AIRAWXJxjumZkITCJoWFRRCMoalDgPGGY ( &$RFUSQDBhzgNhMWwvjrksGInVwEFKGpyDQt, $oekFGtZESkEokLSxylLNkaNEATnxzlxWrvHSsg = 0 )
  {
    if ( $oekFGtZESkEokLSxylLNkaNEATnxzlxWrvHSsg >= 10 )
    {
      return;
    }
    foreach ( $RFUSQDBhzgNhMWwvjrksGInVwEFKGpyDQt as $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE => $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU )
    {
      if ( is_array( $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU ) )
      {
        self::AIRAWXJxjumZkITCJoWFRRCMoalDgPGGY( $RFUSQDBhzgNhMWwvjrksGInVwEFKGpyDQt[ $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE ], ++$oekFGtZESkEokLSxylLNkaNEATnxzlxWrvHSsg );
      }
      else
      {
        $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU = str_replace( chr( '0' ), '', $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU );
        $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU = str_replace( "\0", '', $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU );
        $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU = str_replace( "\x00", '', $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU );
        $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU = str_replace( "../", "&#46;&#46;/", $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU );
        $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU = str_replace( '&#8238;', '', $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU );
        $RFUSQDBhzgNhMWwvjrksGInVwEFKGpyDQt[ $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE ] = $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU;
      }
    }
  }

  static public function ZsYRnxZDEptCpRwWpaTKdgMJIhdrXtSP ( &$RFUSQDBhzgNhMWwvjrksGInVwEFKGpyDQt, $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs = array(), $oekFGtZESkEokLSxylLNkaNEATnxzlxWrvHSsg = 0 )
  {
    if ( $oekFGtZESkEokLSxylLNkaNEATnxzlxWrvHSsg >= 20 )
    {
      return $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs;
    }
    if ( ! is_array( $RFUSQDBhzgNhMWwvjrksGInVwEFKGpyDQt ) )
    {
      return $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs;
    }
    foreach ( $RFUSQDBhzgNhMWwvjrksGInVwEFKGpyDQt as $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE => $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU )
    {
      if ( is_array( $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU ) )
      {
        $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs[ $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE ] = self::ZsYRnxZDEptCpRwWpaTKdgMJIhdrXtSP( $RFUSQDBhzgNhMWwvjrksGInVwEFKGpyDQt[ $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE ], array(), $oekFGtZESkEokLSxylLNkaNEATnxzlxWrvHSsg + 1 );
      }
      else
      {
        $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE = self::HvKKOSrfpFvPGoBxJIaBrhSdSCBxCg( $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE );
        $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU = self::VjYkaEKnVvLWvMrTgceoemoRwYuVgmgQ( $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU );
        $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs[ $pxwnYilulgMtsAPMetxBkCfYZuVWXKleE ] = $vsoUnWAxYIeyfhpklUzbRnsqTRUrzOnPpAcyU;
      }
    }
    return $HJRuoETnZMKIUnnJQBBNMwZbvVhtUZclANs;
  }

  static public function HvKKOSrfpFvPGoBxJIaBrhSdSCBxCg ( $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc )
  {
    if ( $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc === "" )
    {
      return "";
    }
    $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc = htmlspecialchars( urldecode( $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc ) );
    $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc = str_replace( "..", "", $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc );
    $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc = preg_replace( '/\_\_(.+?)\_\_/', "", $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc );
    $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc = preg_replace( '/^([\w\.\-\_]+)$/', "$1", $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc );
    return $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc;
  }

  static public function VjYkaEKnVvLWvMrTgceoemoRwYuVgmgQ ( $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM )
  {
    if ( $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM == "" )
    {
      return "";
    }
    $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM = str_replace( "&#032;", " ", stripslashes( $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM ) );
    $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM = str_replace( array( "\r\n", "\n\r", "\r" ), "\n", $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM );
    $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM = str_replace( "<!--", "&#60;&#33;--", $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM );
    $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM = str_replace( "-->", "--&#62;", $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM );
    $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM = str_ireplace( "<script", "&#60;script", $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM );
    $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM = str_replace( "$", "&#036;", $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM );
    $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM = preg_replace( "/&amp;#([0-9]+);/s", "&#\\1;", $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM );
    $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM = preg_replace( '/&#(\d+?)([^\d;])/i', "&#\\1;\\2", $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM );
    return trim( $iWZBmdEJnXemgpuymvJsIBCAFqBQPnKgvsmM );
  }

  static public function KVfkIrnlxvLbWRYCMcCvTQBYpVZOwNteSE ( )
  {
    self::$mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT * from `multics_licence` WHERE `id` = 1" );
    if ( self::$mcDB->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
    {
      $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs = self::$mcDB->OywkjiJsPsfQksGnfpNDuDtblCYOpOluCAWg( );
      self::$klqHFGteYBcFLfJUzFMxiJDWkivPympnw = $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs;
      return $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'licence_key' ];
    }
    return false;
  }

  static public function lnasVWpWmmWbLdTpCHBvNRkWutjIMeLIZOU ( )
  {
    self::$mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT `setting_key`,`setting_value` from `settings`" );
    $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl = self::$mcDB->uRkfhIjOyHziEyCiTLMEUfuMfkXqDIgnaoo( );
    foreach ( $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl as $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs )
    {
      if ( stristr( $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'setting_value' ], '<|>' ) )
      {
        $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'setting_value' ] = explode( '<|>', $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'setting_value' ] );
      }
      self::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw[ $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'setting_key' ] ] = $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'setting_value' ];
    }
  }

  static public function lZexiFDGXCwLbrAuEZMTDYQnEsbIoOgDaQ ( )
  {
    self::$mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT `ip` FROM `ban_ips`;" );
    $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl = self::$mcDB->uRkfhIjOyHziEyCiTLMEUfuMfkXqDIgnaoo( );
    $CbLovqtcAgWjQiQIvBozYzqqvdSLUfVRKatK = array();
    foreach ( $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl as $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs )
    {
      $CbLovqtcAgWjQiQIvBozYzqqvdSLUfVRKatK[ ] = $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'ip' ];
    }
    return $CbLovqtcAgWjQiQIvBozYzqqvdSLUfVRKatK;
  }

  static public function BmEEysDlmxrvpawhmFFACDXEWCMuaqWJSkOByQ ( )
  {
    self::$mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT `email` FROM `ban_emails`;" );
    $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl = self::$mcDB->uRkfhIjOyHziEyCiTLMEUfuMfkXqDIgnaoo( );
    $cIhMYNlSdHKJuWvDgCemUhCWiTMTgRtTmCA = array();
    foreach ( $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl as $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs )
    {
      $cIhMYNlSdHKJuWvDgCemUhCWiTMTgRtTmCA[ ] = $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'email' ];
    }
    return $cIhMYNlSdHKJuWvDgCemUhCWiTMTgRtTmCA;
  }

  static public function ZGHRtBfgqJVGdOhBSLFUNeaBBWgQUVoJA ( $qtuMXFTmFPbWpjbykgktcYDHbLtybqFsmg )
  {
    if ( is_array( mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw[ 'TESTLINES_DATES' ] ) )
    {
      if ( in_array( $qtuMXFTmFPbWpjbykgktcYDHbLtybqFsmg, mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw[ 'TESTLINES_DATES' ] ) )
      {
        return true;
      }
    }
    else
    {
      if ( $qtuMXFTmFPbWpjbykgktcYDHbLtybqFsmg == mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw[ 'TESTLINES_DATES' ] )
      {
        return true;
      }
    }
    return false;
  }

  static public function PhBQosZlwKZusPeDModuwGmPXqTlnAXQ ( $VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY )
  {
    if ( is_array( mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw[ 'PAYMENT_METHODS' ] ) )
    {
      if ( in_array( $VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY, mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw[ 'PAYMENT_METHODS' ] ) )
      {
        return true;
      }
    }
    else
    {
      if ( $VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY == mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw[ 'PAYMENT_METHODS' ] )
      {
        return true;
      }
    }
    return false;
  }

  static public function TbTtRDCYGOOZOkTpYWGwdpKQcPZQqMWGoE ( $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA )
  {
    $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = true;
    $SahhjOndILFLAkxkECRuSLUWmLPYYWg = strrpos( $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA, "@" );
    if ( is_bool( $SahhjOndILFLAkxkECRuSLUWmLPYYWg ) && ! $SahhjOndILFLAkxkECRuSLUWmLPYYWg )
    {
      $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
    }
    else
    {
      $ohPnetUvJCPtOjwymIltrcNUnhPUXzBU = substr( $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA, $SahhjOndILFLAkxkECRuSLUWmLPYYWg + 1 );
      $vbFosWjVdbxyKmQlJGjpiqiFOuPVdnWKGOvomo = substr( $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA, 0, $SahhjOndILFLAkxkECRuSLUWmLPYYWg );
      $xUqJvTYoOvEyvIlmZnhyskgSeILQmAzNUuHgIM = strlen( $vbFosWjVdbxyKmQlJGjpiqiFOuPVdnWKGOvomo );
      $CAAJLWnXpVYBVzdjWHDyYmOoexIjudlTpElc = strlen( $ohPnetUvJCPtOjwymIltrcNUnhPUXzBU );
      if ( $xUqJvTYoOvEyvIlmZnhyskgSeILQmAzNUuHgIM < 1 || $xUqJvTYoOvEyvIlmZnhyskgSeILQmAzNUuHgIM > 64 )
      {
        $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
      }
      else if ( $CAAJLWnXpVYBVzdjWHDyYmOoexIjudlTpElc < 1 || $CAAJLWnXpVYBVzdjWHDyYmOoexIjudlTpElc > 255 )
      {
        $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
      }
      else if ( preg_match( '/@\\[.+\\]$/ius', $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA ) )
      {
        $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA = preg_replace( '/^(.+?)@(.+)$/ies', '"$1@" . strtolower("$2")', str_replace( "&#036;", "$", $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA ) );
        $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
      }
      else if ( $vbFosWjVdbxyKmQlJGjpiqiFOuPVdnWKGOvomo[ 0 ] == '.' || $vbFosWjVdbxyKmQlJGjpiqiFOuPVdnWKGOvomo[ $xUqJvTYoOvEyvIlmZnhyskgSeILQmAzNUuHgIM - 1 ] == '.' )
      {
        $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
      }
      else if ( preg_match( '/\\.\\./', $vbFosWjVdbxyKmQlJGjpiqiFOuPVdnWKGOvomo ) )
      {
        $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
      }
      else if ( ! preg_match( '/^[A-Za-z0-9\\-\\.]+$/', $ohPnetUvJCPtOjwymIltrcNUnhPUXzBU ) )
      {
        $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
      }
      else if ( preg_match( '/\\.\\./', $ohPnetUvJCPtOjwymIltrcNUnhPUXzBU ) )
      {
        $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
      }
      else if ( ! preg_match( '/^(\\\\.|[A-Za-z0-9!#%&`_=\\/$\'*+?^{}|~.-])+$/', str_replace( "\\\\", "", $vbFosWjVdbxyKmQlJGjpiqiFOuPVdnWKGOvomo ) ) )
      {
        if ( ! preg_match( '/^"(\\\\""|[^"])+"$/', str_replace( "\\\\", "", $vbFosWjVdbxyKmQlJGjpiqiFOuPVdnWKGOvomo ) ) )
        {
          $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
        }
      }
      if ( $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe && ! (checkdnsrr( $ohPnetUvJCPtOjwymIltrcNUnhPUXzBU, "MX" ) || checkdnsrr( $ohPnetUvJCPtOjwymIltrcNUnhPUXzBU, "A" )) )
      {
        $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe = false;
      }
    }
    return $yCcXYFPAChUByCIjEdkoBqxDzzlhBGe;
  }

  static public function UQlwNexQoDmmrECjtSvjXkCemiUXftVlJ ( $IEWEXXOiJxnfhblqILVuzTjfANUGWSTzPOQ = 10 )
  {
    $SZxjQXmKHMpTnREiIaibcydmqMwkIZmk = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $EmkIYGcWyslZJUQYtPrLhknzfZZShGKxWIQ = '';
    $ShoiwDLtNtAmnCUOVkMUAjvXMtBdnJclgtLi = strlen( $SZxjQXmKHMpTnREiIaibcydmqMwkIZmk ) - 1;
    for ( $PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII = 0; $PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII < $IEWEXXOiJxnfhblqILVuzTjfANUGWSTzPOQ; $PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII++ )
      $EmkIYGcWyslZJUQYtPrLhknzfZZShGKxWIQ .= $SZxjQXmKHMpTnREiIaibcydmqMwkIZmk[ rand( 0, $ShoiwDLtNtAmnCUOVkMUAjvXMtBdnJclgtLi ) ];
    return $EmkIYGcWyslZJUQYtPrLhknzfZZShGKxWIQ;
  }

  static public function sLYQRInHqFhKEHlZrlkIQnxTDtZrYVNtKK ( $xVsdXLfYVLgEWyTlxJpGgTxKLQUFXBzRCU )
  {
    $rpdfVOBigGuMcolCcPAfUBsyLPyNCgLtQngwE = array();
    foreach ( $xVsdXLfYVLgEWyTlxJpGgTxKLQUFXBzRCU as $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM )
    {
      if ( is_scalar( $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM ) or is_resource( $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM ) )
      {
        $rpdfVOBigGuMcolCcPAfUBsyLPyNCgLtQngwE[ ] = $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM;
      }
      elseif ( is_array( $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM ) )
      {
        $rpdfVOBigGuMcolCcPAfUBsyLPyNCgLtQngwE = array_merge( $rpdfVOBigGuMcolCcPAfUBsyLPyNCgLtQngwE, self::sLYQRInHqFhKEHlZrlkIQnxTDtZrYVNtKK( $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM ) );
      }
    }
    return $rpdfVOBigGuMcolCcPAfUBsyLPyNCgLtQngwE;
  }
}
?>
