<?php
/**
  * @multics panel v4.2 release 07-11-2020
  * @oscam, multics, iptv 3in1 panel
  * @developer: Muhammad Ashan (Xtream-Masters.com)
*/
eval(base64_decode("aWYgKCFleHRlbnNpb25fbG9hZGVkKCJ4dHJlYW1tYXN0ZXJzIikpCnsKZXhpdCgiWW91IE5lZWQgWHRyZWFtTWFzdGVycyBQaHAgRXh0ZW5zaW9uIik7Cn0="));
Xtreammasters\Cccam::iptv("Developer_Muhammad_Ashan_{+_best-cccam-&-iptv-software-solution_+}Z5vZq+Q9yHoAaZ6ccyoXI8uWO3a6pAUwQZamCvDUee3/eTZ6dee5EjTn5YMJpkD2LNxdo7ESNOP45AWt07EZOeU4YuhpUjoZ/rW4rGe5ZlefItJpXdNiA+QLgeuZUpMTQaKuB7c3NmHGAg/9AQQUwwxO8gwAQYS7FCov+s5+aS6RUziWRIEO+CHx/NrpQl1QRQxlGi3HROKWRc5nCNaDfw===we_provide_best_cccam_&_iptv_custom_module_and_tools_or_web_development_services===xtream-masters.com}");
?>