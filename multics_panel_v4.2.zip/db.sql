 --
-- Database BackUP 
--
-- Export created: 2020/12/09 on 11:15


--
-- Database : multics_dbv4
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `ban_emails`
--
DROP TABLE IF EXISTS `ban_emails`;
CREATE TABLE `ban_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `ban_ips`
--
DROP TABLE IF EXISTS `ban_ips`;
CREATE TABLE `ban_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `cronjobs`
--
DROP TABLE IF EXISTS `cronjobs`;
CREATE TABLE `cronjobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `filename` text NOT NULL,
  `run_per_mins` int(11) NOT NULL DEFAULT '1',
  `enabled` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `cronjobs` VALUES ( "1","MultiCS Config Update","multics_cronjob.php","1","0");
INSERT INTO `cronjobs` VALUES ( "2","MultiCS Resharing Monitor","monitor_cronjob.php","1","1");
INSERT INTO `cronjobs` VALUES ( "3","MultiCS Line Online Status","online_cronjob.php","2","1");
INSERT INTO `cronjobs` VALUES ( "4","Notifies the user of the expiration date of his line (via email)","notify_cronjob.php","4","1");
INSERT INTO `cronjobs` VALUES ( "5","Check Online Status For MultiCS Servers","check_status_cronjob.php","7","1");
INSERT INTO `cronjobs` VALUES ( "6","Oscam User Update","oscam_cronjob.php","1","1");


--
-- Tabel structure for table `custom_pages`
--
DROP TABLE IF EXISTS `custom_pages`;
CREATE TABLE `custom_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` text NOT NULL,
  `page_content` text NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `emulators`
--
DROP TABLE IF EXISTS `emulators`;
CREATE TABLE `emulators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emulator_name` varchar(20) NOT NULL,
  `user_access` int(11) NOT NULL,
  `can_multiple` int(11) NOT NULL,
  `default_server_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `emulators` VALUES ( "1","CCcam","1","1","0");
INSERT INTO `emulators` VALUES ( "2","MgCamd","1","1","0");
INSERT INTO `emulators` VALUES ( "3","NewCamd","1","0","0");


--
-- Tabel structure for table `group_packages`
--
DROP TABLE IF EXISTS `group_packages`;
CREATE TABLE `group_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `iptv_pack`
--
DROP TABLE IF EXISTS `iptv_pack`;
CREATE TABLE `iptv_pack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext,
  `price` tinytext,
  `value` tinytext NOT NULL,
  `bid` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `iptv_pack` VALUES ( "1","1 Month","2","1","5");
INSERT INTO `iptv_pack` VALUES ( "23","1 Month","2","1","10");
INSERT INTO `iptv_pack` VALUES ( "4","3 Months","6","2","5");
INSERT INTO `iptv_pack` VALUES ( "5","6 Months","11","3","5");
INSERT INTO `iptv_pack` VALUES ( "6","One Year","20","4","5");
INSERT INTO `iptv_pack` VALUES ( "7","Two Days","","11","5");
INSERT INTO `iptv_pack` VALUES ( "8","1 Month","2","1","7");
INSERT INTO `iptv_pack` VALUES ( "9","3 Months","6","2","7");
INSERT INTO `iptv_pack` VALUES ( "10","6 Months","11","3","7");
INSERT INTO `iptv_pack` VALUES ( "11","One Year","20","4","7");
INSERT INTO `iptv_pack` VALUES ( "12","Two Days","","11","7");
INSERT INTO `iptv_pack` VALUES ( "27","Two Days","","11","10");
INSERT INTO `iptv_pack` VALUES ( "26","One Year","20","4","10");
INSERT INTO `iptv_pack` VALUES ( "25","6 Months","11","3","10");
INSERT INTO `iptv_pack` VALUES ( "24","3 Months","6","2","10");
INSERT INTO `iptv_pack` VALUES ( "18","1 Month","2","1","9");
INSERT INTO `iptv_pack` VALUES ( "19","3 Months","6","2","9");
INSERT INTO `iptv_pack` VALUES ( "20","6 Months","11","3","9");
INSERT INTO `iptv_pack` VALUES ( "21","One Year","20","4","9");
INSERT INTO `iptv_pack` VALUES ( "22","One Day","","11","9");


--
-- Tabel structure for table `iptv_pnb`
--
DROP TABLE IF EXISTS `iptv_pnb`;
CREATE TABLE `iptv_pnb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext,
  `bid` tinytext NOT NULL,
  `display` tinyint(4) NOT NULL,
  `des` tinytext NOT NULL,
  `tc` tinytext NOT NULL,
  `sc` tinytext NOT NULL,
  `ec` tinytext NOT NULL,
  `o` tinytext NOT NULL,
  `icon` tinytext NOT NULL,
  `is_trail` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `iptv_pnb` VALUES ( "7","All Channels - IPTV","[1021,1112,1148,1059,1060,1064,1020,1054,1048]","1","All Channels (No Adults)<br> (<b>No Movies</b>) <br>(5000+ Channels)<br>IPTV Subscription","FFFFFF","2B8C5C","1B798C","1","glyphicon glyphicon-plus","0");
INSERT INTO `iptv_pnb` VALUES ( "5","All Channels + Movies","[1022,1128,1023,1045,1130,1021,1075,1112,1148,1059,1060,1027,1064,1020,1132,1054,1048]","1","All Channels <b>With Movies</b> <br>(No Adults)<br>5000+ Channels <br> 33,000+ Movies","FFFFFF","2B8C76","1B5F8C","2","glyphicon glyphicon-piggy-bank","0");
INSERT INTO `iptv_pnb` VALUES ( "10","All Channels + Adults","[1045,1021,1112,1148,1059,1064,1020,1111,1054,1048]","1","All Channels With Adults <br>(<b>No Movies</b>) <br>5000+ Channels<br>IPTV Subscription","FFFFFF","FF4019","FF711F","3","glyphicon glyphicon-piggy-bank","0");
INSERT INTO `iptv_pnb` VALUES ( "9","All Channels + Movies","[1028,1045,1130,1021,1075,1112,1148,1059,1064,1020,1111,1110,1054,1048]","1","All Channels <b>With Movies</b> <br>(With Adults)<br>5000+ Channels <br> 33,000+ Movies","FFFFFF","FF8629","FF421C","4"," glyphicon glyphicon-hdd","0");


--
-- Tabel structure for table `languages`
--
DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_title` varchar(10) NOT NULL,
  `file_name` text NOT NULL,
  `default_guests` int(11) NOT NULL DEFAULT '0',
  `can_delete` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `languages` VALUES ( "1","English","english","1","0");


--
-- Tabel structure for table `lines`
--
DROP TABLE IF EXISTS `lines`;
CREATE TABLE `lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `server_id` int(11) NOT NULL,
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  `profiles` text NOT NULL,
  `test_line` tinyint(4) NOT NULL,
  `blocked` int(11) NOT NULL DEFAULT '0',
  `enable` int(11) NOT NULL DEFAULT '1',
  `notes` varchar(25) DEFAULT NULL,
  `user_paid` double NOT NULL DEFAULT '0',
  `line_options` text NOT NULL,
  `monitor_exclude` int(11) NOT NULL DEFAULT '0',
  `allow_ch_emu` int(11) NOT NULL DEFAULT '1',
  `reshare` int(11) NOT NULL DEFAULT '0',
  `online` int(11) NOT NULL DEFAULT '0',
  `multics_id` int(11) NOT NULL DEFAULT '0',
  `notified_expire` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `server_id` (`server_id`)
) ENGINE=MyISAM AUTO_INCREMENT=944 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `lines_options`
--
DROP TABLE IF EXISTS `lines_options`;
CREATE TABLE `lines_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_name` text NOT NULL,
  `duration` int(11) NOT NULL,
  `duration_in` varchar(1) NOT NULL,
  `option_type` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `normal_price` double NOT NULL,
  `profiles` text NOT NULL,
  `info` text NOT NULL,
  `allow_ch_emu` int(11) NOT NULL DEFAULT '1',
  `monitor_exclude` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `lines_options` VALUES ( "11","Dishtv CCcam","1","d","0","33","1","121,122","","1","0");
INSERT INTO `lines_options` VALUES ( "12","Dishtv CCcam","1","m","1","33","30","121,122","","1","0");
INSERT INTO `lines_options` VALUES ( "13","Dishtv CCcam","3","m","1","33","90","121,122","","1","0");
INSERT INTO `lines_options` VALUES ( "14","Dishtv CCcam","6","m","1","33","180","121,122","","1","0");
INSERT INTO `lines_options` VALUES ( "15","Dishtv CCcam","12","m","1","33","350","121,122","","1","0");
INSERT INTO `lines_options` VALUES ( "16","Allsat CCcam","1","d","0","34","1","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "17","Allsat CCcam","1","m","1","34","50","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "18","Allsat CCcam","3","m","1","34","150","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "19","Allsat CCcam","6","m","1","34","300","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "20","Allsat CCcam","12","m","1","34","500","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "21","MGcamd Subscription","12","h","0","35","0","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "22","MGcamd Subscription","1","m","1","35","50","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "23","MGcamd Subscription","3","m","1","35","150","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "24","MGcamd Subscription","6","m","1","35","300","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");
INSERT INTO `lines_options` VALUES ( "25","MGcamd Subscription","12","m","1","35","500","121,120,119,118,117,116,115,114,113,112,111,110,122","","1","0");


--
-- Tabel structure for table `member_groups`
--
DROP TABLE IF EXISTS `member_groups`;
CREATE TABLE `member_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` text NOT NULL,
  `group_color` varchar(7) NOT NULL DEFAULT '#000000',
  `is_banned` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `percent_discount` int(11) NOT NULL DEFAULT '0',
  `total_testlines` int(11) NOT NULL DEFAULT '1',
  `can_delete` tinyint(4) NOT NULL DEFAULT '1',
  `iptv` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `member_groups` VALUES ( "1","Administrators","#008852","0","1","50","100","0","1");
INSERT INTO `member_groups` VALUES ( "2","Banned","#030301","1","0","0","0","0","");
INSERT INTO `member_groups` VALUES ( "3","Registered Users","#0c00ff","0","0","0","1","0","0");
INSERT INTO `member_groups` VALUES ( "4","Reseller - 12 Month","#3c26d6","0","0","5","100","0","1");
INSERT INTO `member_groups` VALUES ( "5","Pro-Reseller","#d45f00","0","0","0","50","0","1");
INSERT INTO `member_groups` VALUES ( "6","Sub-Reseller","#039311","0","0","0","10","0","1");


--
-- Tabel structure for table `monitor`
--
DROP TABLE IF EXISTS `monitor`;
CREATE TABLE `monitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL,
  `latest_zaps` int(11) NOT NULL,
  `diff` int(11) NOT NULL,
  `warnings` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `multics_config_vars`
--
DROP TABLE IF EXISTS `multics_config_vars`;
CREATE TABLE `multics_config_vars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_value_name` text NOT NULL,
  `config_value` text NOT NULL,
  `master_server_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `multics_licence`
--
DROP TABLE IF EXISTS `multics_licence`;
CREATE TABLE `multics_licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence_key` tinytext NOT NULL,
  `show_message` tinyint(4) NOT NULL,
  `update_available` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `multics_licence` VALUES ( "1","yF6AckuDgYHf1R2DV8xZ/fUA/AaLvz1GwFxDWu0o6anpK0Of94cZQm+eo1bCCeN1yDpFuZ1dVBBrIjTTqPVM0w==","0","0");


--
-- Tabel structure for table `multics_master_servers`
--
DROP TABLE IF EXISTS `multics_master_servers`;
CREATE TABLE `multics_master_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `port` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `monitor_enabled` int(11) NOT NULL DEFAULT '1',
  `oscam_readers` text,
  `server_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `multics_server_emulators`
--
DROP TABLE IF EXISTS `multics_server_emulators`;
CREATE TABLE `multics_server_emulators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emulator_id` int(11) NOT NULL,
  `master_server_id` int(11) NOT NULL,
  `user_access` int(11) NOT NULL,
  `default_server_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `multics_servers`
--
DROP TABLE IF EXISTS `multics_servers`;
CREATE TABLE `multics_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emulator_id` int(11) NOT NULL,
  `domain_name` text NOT NULL,
  `description` text,
  `port` int(11) NOT NULL,
  `master_server_id` int(11) DEFAULT NULL,
  `can_delete` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `payments`
--
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_txn` text NOT NULL,
  `member_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `payer_email` text,
  `date` int(11) NOT NULL,
  `payment_method` text NOT NULL,
  `accepted` int(11) NOT NULL DEFAULT '0',
  `notes` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `profiles`
--
DROP TABLE IF EXISTS `profiles`;
CREATE TABLE `profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(60) NOT NULL,
  `profile_options` text NOT NULL,
  `master_server_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `server_news`
--
DROP TABLE IF EXISTS `server_news`;
CREATE TABLE `server_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_title` text NOT NULL,
  `news_content` text NOT NULL,
  `date` int(11) NOT NULL,
  `member_groups` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `settings`
--
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` text NOT NULL,
  `setting_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;

INSERT INTO `settings` VALUES ( "1","SERVER_NAME","Best CCcam Server");
INSERT INTO `settings` VALUES ( "2","MIN_PASSWORD","6");
INSERT INTO `settings` VALUES ( "3","ALLOW_REGISTRATIONS","1");
INSERT INTO `settings` VALUES ( "4","CAN_GENERATE_NEW_DAYS","40");
INSERT INTO `settings` VALUES ( "6","PAYPAL_EMAIL","");
INSERT INTO `settings` VALUES ( "7","CONFIRMATION_EMAIL","1");
INSERT INTO `settings` VALUES ( "8","DISCOUNT_SYSTEM","1");
INSERT INTO `settings` VALUES ( "9","DISCOUNT_IN_X_LINES","5");
INSERT INTO `settings` VALUES ( "10","CURRENCY_CODE","USD");
INSERT INTO `settings` VALUES ( "11","MAIL_FROM","");
INSERT INTO `settings` VALUES ( "12","SERVER_SMTP","0");
INSERT INTO `settings` VALUES ( "13","SMTP_HOST","");
INSERT INTO `settings` VALUES ( "14","SMTP_PORT","");
INSERT INTO `settings` VALUES ( "15","SMTP_ENCRYPTION","tls");
INSERT INTO `settings` VALUES ( "16","SMTP_USERNAME","");
INSERT INTO `settings` VALUES ( "17","SMTP_PASSWORD","");
INSERT INTO `settings` VALUES ( "18","SMTP_FROM_NAME","");
INSERT INTO `settings` VALUES ( "19","TEST_LINE_ENABLE","1");
INSERT INTO `settings` VALUES ( "20","ACCEPT_PAYMENTS","1");
INSERT INTO `settings` VALUES ( "21","ALLOW_SECOND_ACCOUNT","1");
INSERT INTO `settings` VALUES ( "22","PAYMENT_METHODS","custom");
INSERT INTO `settings` VALUES ( "23","DELETE_LINES_IN","2");
INSERT INTO `settings` VALUES ( "24","CAN_DELETE_LINES","1");
INSERT INTO `settings` VALUES ( "25","REMOVE_LINECOST_PERCENT","10");
INSERT INTO `settings` VALUES ( "26","ENABLE_TICKETS","1");
INSERT INTO `settings` VALUES ( "27","USERNAME_ALPHA","1");
INSERT INTO `settings` VALUES ( "28","USERNAME_STRLEN","15");
INSERT INTO `settings` VALUES ( "29","MONITOR_LAST_MIN_ZAPS","");
INSERT INTO `settings` VALUES ( "30","ENABLE_PAYPAL_SHIELD","0");
INSERT INTO `settings` VALUES ( "31","PAYPAL_SHIELD","http://www.your-shieldsite.com/");
INSERT INTO `settings` VALUES ( "32","PAYPAL_CMD","_donations");
INSERT INTO `settings` VALUES ( "33","PAYPAL_ITEM_NAME","");
INSERT INTO `settings` VALUES ( "34","MULTICS_DOMAIN","127.0.0.1");
INSERT INTO `settings` VALUES ( "35","MULTICS_USER","");
INSERT INTO `settings` VALUES ( "36","MULTICS_PASS","");
INSERT INTO `settings` VALUES ( "37","MULTICS_PORT","");
INSERT INTO `settings` VALUES ( "38","TESTLINES_DATES","Monday<|>Tuesday<|>Wednesday<|>Thursday<|>Friday<|>Saturday<|>Sunday");
INSERT INTO `settings` VALUES ( "39","CAPTCHA_LOGIN","0");
INSERT INTO `settings` VALUES ( "40","CAPTCHA_REGISTER","0");
INSERT INTO `settings` VALUES ( "41","CAPTCHA_FORGOT","0");
INSERT INTO `settings` VALUES ( "42","ENABLE_EMAIL_BAN_LIST","0");
INSERT INTO `settings` VALUES ( "43","ENABLE_IP_BAN_LIST","0");
INSERT INTO `settings` VALUES ( "45","EXPIRELINE_INFORM_USER_HOURS","48");
INSERT INTO `settings` VALUES ( "46","PAYPAL_ORDER_ID","1");
INSERT INTO `settings` VALUES ( "47","PAYPAL_INVOICE","0");
INSERT INTO `settings` VALUES ( "48","PAYPAL_THANKYOU","");
INSERT INTO `settings` VALUES ( "49","PAYPAL_HEADER_IMG","");
INSERT INTO `settings` VALUES ( "51","REQUIRE_TID","1");
INSERT INTO `settings` VALUES ( "52","REQUIRE_TP","1");
INSERT INTO `settings` VALUES ( "53","CAN_PAYMENT_HISTORY","1");
INSERT INTO `settings` VALUES ( "55","EMAIL_MSG_FORGOT","<p>Hello,</p><p>You just asked to reset your password. If it wasn&#39;t you then just ignore this e-mail. To verify the forgot password click on the following link:</p><p>{FORGOT_LINK}</p><p>Thank you!<br />{SERVER_NAME}</p>");
INSERT INTO `settings` VALUES ( "56","EMAIL_MSG_VERIFY","<p>Hello,</p><p>To complete your registration please visit the following link:</p><p>{VERIFY_LINK}</p><p>Thank you!<br />{SERVER_NAME}</p>");
INSERT INTO `settings` VALUES ( "57","EMAIL_MSG_EXPIRE_LINE","<p>Hello {MEMBER_NAME},</p><p>Your Line with username {LINE_USERNAME} will expire soon. Expire Date: {EXPIRE_DATE}<br /><br />If you want you can extend it anytime you want from the userpanel.</p><p>Thank you<br />{SERVER_NAME}</p>");
INSERT INTO `settings` VALUES ( "58","EMAIL_MSG_MONITOR_BAN","<p>Hello {MEMBER_NAME},</p><p>We noticed that your line {LINE_USERNAME} is used for resharing and for that reason is now blocked.</p><p>Please Contact with us<br />{SERVER_NAME}</p>");
INSERT INTO `settings` VALUES ( "59","EMAIL_MSG_MONITOR_WARN","<p>Hello {MEMBER_NAME},</p><p>We noticed that your line {LINE_USERNAME} is used for resharing. This is just a warning. You have to stop the resharing otherwise your line will be blocked.</p><p>Please Contact with us<br />{SERVER_NAME}</p>");
INSERT INTO `settings` VALUES ( "60","EMAIL_MSG_FORGOT_SUB","Forgot Password Request @ {SERVER_NAME}");
INSERT INTO `settings` VALUES ( "61","EMAIL_MSG_MONITOR_WARN_SUB","{SERVER_NAME} - Resharing - WARNING");
INSERT INTO `settings` VALUES ( "62","EMAIL_MSG_EXPIRE_LINE_SUB","{SERVER_NAME} - Your Line Will Expire Soon");
INSERT INTO `settings` VALUES ( "63","EMAIL_MSG_MONITOR_BAN_SUB","{SERVER_NAME} - Resharing - Line Blocked");
INSERT INTO `settings` VALUES ( "64","EMAIL_MSG_VERIFY_SUB","Registration @ {SERVER_NAME}");
INSERT INTO `settings` VALUES ( "65","FULL_URL","");
INSERT INTO `settings` VALUES ( "66","MONITOR_AUTO_BLOCK","0");
INSERT INTO `settings` VALUES ( "67","MONITOR_BLOCK_WARNINGS","3");
INSERT INTO `settings` VALUES ( "68","MONITOR_BLOCK_INFORM","1");
INSERT INTO `settings` VALUES ( "69","REMOVE_COPYRIGHTS","1");
INSERT INTO `settings` VALUES ( "70","OWN_COPYRIGHTS","");
INSERT INTO `settings` VALUES ( "71","LOGO_URL","https://paksat.pk/Webp.net-gifmaker.gif");


--
-- Tabel structure for table `tickets_post`
--
DROP TABLE IF EXISTS `tickets_post`;
CREATE TABLE `tickets_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `post` text NOT NULL,
  `admin_reply` int(11) NOT NULL DEFAULT '0',
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic_id` (`topic_id`,`admin_reply`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tickets_topics`
--
DROP TABLE IF EXISTS `tickets_topics`;
CREATE TABLE `tickets_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `topic_title` varchar(70) NOT NULL,
  `date` int(11) NOT NULL,
  `admin_read` int(11) NOT NULL DEFAULT '0',
  `user_read` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`,`admin_read`,`user_read`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tvstar_activecode`
--
DROP TABLE IF EXISTS `tvstar_activecode`;
CREATE TABLE `tvstar_activecode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conx` tinytext NOT NULL,
  `exdate` varchar(10) NOT NULL,
  `name` tinytext,
  `activecode` tinytext,
  `mac` tinytext NOT NULL,
  `startfrom` varchar(10) NOT NULL,
  `price` tinytext NOT NULL,
  `port` varchar(11) NOT NULL,
  `is_trial` tinytext NOT NULL,
  `bouquet` tinytext NOT NULL,
  `notice` tinytext NOT NULL,
  `expare` tinytext NOT NULL,
  `blocked` tinytext NOT NULL,
  `server` tinytext NOT NULL,
  `linename` tinytext NOT NULL,
  `category` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tvstar_iptv`
--
DROP TABLE IF EXISTS `tvstar_iptv`;
CREATE TABLE `tvstar_iptv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conx` tinytext NOT NULL,
  `exdate` varchar(10) NOT NULL,
  `name` tinytext,
  `user` tinytext,
  `pass` tinytext NOT NULL,
  `startfrom` varchar(10) NOT NULL,
  `price` tinytext NOT NULL,
  `port` varchar(11) NOT NULL,
  `is_trial` tinytext NOT NULL,
  `bouquet` tinytext NOT NULL,
  `notice` tinytext NOT NULL,
  `expare` tinytext NOT NULL,
  `blocked` tinytext NOT NULL,
  `server` tinytext NOT NULL,
  `linename` tinytext NOT NULL,
  `category` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tvstar_mac`
--
DROP TABLE IF EXISTS `tvstar_mac`;
CREATE TABLE `tvstar_mac` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conx` tinytext NOT NULL,
  `exdate` varchar(10) NOT NULL,
  `name` tinytext,
  `address` tinytext,
  `mac` tinytext NOT NULL,
  `startfrom` varchar(10) NOT NULL,
  `price` tinytext NOT NULL,
  `port` varchar(11) NOT NULL,
  `is_trial` tinytext NOT NULL,
  `bouquet` tinytext NOT NULL,
  `notice` tinytext NOT NULL,
  `expare` tinytext NOT NULL,
  `blocked` tinytext NOT NULL,
  `server` tinytext NOT NULL,
  `linename` tinytext NOT NULL,
  `category` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `users`
--
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(250) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `date_registered` int(11) NOT NULL,
  `verify_key` varchar(10) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `balance` double NOT NULL DEFAULT '0',
  `member_group_id` int(4) NOT NULL,
  `verified` tinyint(4) NOT NULL DEFAULT '0',
  `total_test_lines` int(11) DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '1',
  `ref_id` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=366 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES ( "1","admin","d8578edf8458ce06fbc5bb76a58c5ca4","yourmail@admin.com","176.9.142.116","1404254166","TO0MW9H9Z4","1607501733","9999","1","1","0","1",NULL);


--
-- Tabel structure for table `users_sessions`
--
DROP TABLE IF EXISTS `users_sessions`;
CREATE TABLE `users_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `session_id` varchar(50) NOT NULL,
  `user_agent` text NOT NULL,
  `ip` varchar(15) NOT NULL,
  `expire_date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `users_sessions` VALUES ( "5","1","nderajspod9sqtukci6qaugifi","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36","176.9.142.116","1607503544");
INSERT INTO `users_sessions` VALUES ( "2","256","vhiqu821rvho8uq1kjvq5dea63","Mozilla/5.0 (Linux; U; Android 9; en-US; Infinix X650C Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.108 UCBrowser/13.2.8.1301 Mobile Safari/537.36","168.235.197.165","1606132081");


